<?php
// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if( !class_exists( 'bbPress' ) ) {
	return 0;
}

include_once ( 'vc_wtr.php' );

class VCExtendAddonBbpForumIndex extends VCExtendAddonWtr{

	public $base	= 'vc_wtr_bbp_forum_index';
	public $fields	= array();

	//===FUNCTIONS
	public function __construct(){

		parent::__construct();

		// We safely integrate with VC with this hook
		add_action( 'init', array( &$this, 'integrateWithVC' ) );

		//Creating a shortcode addon
		add_shortcode( $this->base, array( &$this, 'render' ) );
	}//end __construct


	public function integrateWithVC(){
		// Map fields

		$this->fields = array(
			$this->getDefaultVCfield( 'el_class' ),
		);

		// animate attr
		$this->shtAnimateAttrGenerator( $this->fields, true );

		vc_map( array(
			'name'			=> __( 'Forum Index', 'wtr_sht_framework' ),
			'description'	=> __( 'This will display your entire forum index', 'wtr_sht_framework' ),
			'base'			=> $this->base,
			'class'			=> $this->base . '_div '. $this->wtrShtMainClass,
			'icon'			=> 'vc_wtr_bbp_icon',
			'controls'		=> 'full',
			'category'		=> $this->groupSht[ 'bbpress' ],
			'params'		=> $this->fields,
			)
		);
	}//end integrateWithVC


	public function render( $atts, $content = null ){
		$atts	= $this->prepareCorrectShortcode( $this->fields, $atts );
		extract( $atts );

		$class_html_attr	= 'wtrBbp-forum-index ' . $el_class;

		$result	='<div' . $this->shtAnimateHTML( $class_html_attr, $atts ) . ' >[bbp-forum-index]</div>';
		$result = do_shortcode( $result );

		return $result;
	}//end Render
}//end VCExtendAddonBbpForumIndex


class VCExtendAddonBbpLogin extends VCExtendAddonWtr{

	public $base	= 'vc_wtr_bbp_login';
	public $fields	= array();

	//===FUNCTIONS
	public function __construct(){

		parent::__construct();

		// We safely integrate with VC with this hook
		add_action( 'init', array( &$this, 'integrateWithVC' ) );

		//Creating a shortcode addon
		add_shortcode( $this->base, array( &$this, 'render' ) );
	}//end __construct


	public function integrateWithVC(){
		// Map fields

		$this->fields = array(
			$this->getDefaultVCfield( 'el_class' ),
		);

		// animate attr
		$this->shtAnimateAttrGenerator( $this->fields, true );

		vc_map( array(
			'name'			=> __( 'Login screen', 'wtr_sht_framework' ),
			'description'	=> __( 'Display the login screen', 'wtr_sht_framework' ),
			'base'			=> $this->base,
			'class'			=> $this->base . '_div '. $this->wtrShtMainClass,
			'icon'			=> 'vc_wtr_bbp_icon',
			'controls'		=> 'full',
			'category'		=> $this->groupSht[ 'bbpress' ],
			'params'		=> $this->fields,
			)
		);
	}//end integrateWithVC


	public function render( $atts, $content = null ){
		$atts	= $this->prepareCorrectShortcode( $this->fields, $atts );
		extract( $atts );

		$class_html_attr	= 'wtrBbp-login ' . $el_class;

		$result	='<div' . $this->shtAnimateHTML( $class_html_attr, $atts ) . ' >[bbp-login]</div>';
		$result = do_shortcode( $result );

		return $result;
	}//end Render
}//end VCExtendAddonBbpLogin


class VCExtendAddonBbpRegister extends VCExtendAddonWtr{

	public $base	= 'vc_wtr_bbp_register';
	public $fields	= array();

	//===FUNCTIONS
	public function __construct(){

		parent::__construct();

		// We safely integrate with VC with this hook
		add_action( 'init', array( &$this, 'integrateWithVC' ) );

		//Creating a shortcode addon
		add_shortcode( $this->base, array( &$this, 'render' ) );
	}//end __construct


	public function integrateWithVC(){
		// Map fields

		$this->fields = array(
			$this->getDefaultVCfield( 'el_class' ),
		);

		// animate attr
		$this->shtAnimateAttrGenerator( $this->fields, true );

		vc_map( array(
			'name'			=> __( 'Register screen', 'wtr_sht_framework' ),
			'description'	=> __( 'Display the register screen', 'wtr_sht_framework' ),
			'base'			=> $this->base,
			'class'			=> $this->base . '_div '. $this->wtrShtMainClass,
			'icon'			=> 'vc_wtr_bbp_icon',
			'controls'		=> 'full',
			'category'		=> $this->groupSht[ 'bbpress' ],
			'params'		=> $this->fields,
			)
		);
	}//end integrateWithVC


	public function render( $atts, $content = null ){
		$atts	= $this->prepareCorrectShortcode( $this->fields, $atts );
		extract( $atts );

		$class_html_attr	= 'wtrBbp-register ' . $el_class;

		$result	='<div' . $this->shtAnimateHTML( $class_html_attr, $atts ) . ' >[bbp-register]</div>';
		$result = do_shortcode( $result );

		return $result;
	}//end Render
}//end VCExtendAddonBbpRegister


class VCExtendAddonBbpLostPass extends VCExtendAddonWtr{

	public $base	= 'vc_wtr_bbp_lost_pass';
	public $fields	= array();

	//===FUNCTIONS
	public function __construct(){

		parent::__construct();

		// We safely integrate with VC with this hook
		add_action( 'init', array( &$this, 'integrateWithVC' ) );

		//Creating a shortcode addon
		add_shortcode( $this->base, array( &$this, 'render' ) );
	}//end __construct


	public function integrateWithVC(){
		// Map fields

		$this->fields = array(
			$this->getDefaultVCfield( 'el_class' ),
		);

		// animate attr
		$this->shtAnimateAttrGenerator( $this->fields, true );

		vc_map( array(
			'name'			=> __( 'Lost password screen', 'wtr_sht_framework' ),
			'description'	=> __( 'Display the lost password screen', 'wtr_sht_framework' ),
			'base'			=> $this->base,
			'class'			=> $this->base . '_div '. $this->wtrShtMainClass,
			'icon'			=> 'vc_wtr_bbp_icon',
			'controls'		=> 'full',
			'category'		=> $this->groupSht[ 'bbpress' ],
			'params'		=> $this->fields,
			)
		);
	}//end integrateWithVC


	public function render( $atts, $content = null ){
		$atts	= $this->prepareCorrectShortcode( $this->fields, $atts );
		extract( $atts );

		$class_html_attr	= 'wtrBbp-lost-pass ' . $el_class;

		$result	='<div' . $this->shtAnimateHTML( $class_html_attr, $atts ) . ' >[bbp-lost-pass]</div>';
		$result = do_shortcode( $result );

		return $result;
	}//end Render
}//end VCExtendAddonBbpLostPass


class VCExtendAddonBbpSearch extends VCExtendAddonWtr{

	public $base	= 'vc_wtr_bbp_search';
	public $fields	= array();

	//===FUNCTIONS
	public function __construct(){

		parent::__construct();

		// We safely integrate with VC with this hook
		add_action( 'init', array( &$this, 'integrateWithVC' ) );

		//Creating a shortcode addon
		add_shortcode( $this->base, array( &$this, 'render' ) );
	}//end __construct


	public function integrateWithVC(){
		// Map fields

		$this->fields = array(
			$this->getDefaultVCfield( 'el_class' ),
		);

		// animate attr
		$this->shtAnimateAttrGenerator( $this->fields, true );

		vc_map( array(
			'name'			=> __( 'Search input form', 'wtr_sht_framework' ),
			'description'	=> __( 'Display the search input form', 'wtr_sht_framework' ),
			'base'			=> $this->base,
			'class'			=> $this->base . '_div '. $this->wtrShtMainClass,
			'icon'			=> 'vc_wtr_bbp_icon',
			'controls'		=> 'full',
			'category'		=> $this->groupSht[ 'bbpress' ],
			'params'		=> $this->fields,
			)
		);
	}//end integrateWithVC


	public function render( $atts, $content = null ){
		$atts	= $this->prepareCorrectShortcode( $this->fields, $atts );
		extract( $atts );

		$class_html_attr	= 'wtrBbp-search ' . $el_class;

		$result	='<div' . $this->shtAnimateHTML( $class_html_attr, $atts ) . ' >[bbp-search]</div>';
		$result = do_shortcode( $result );

		return $result;
	}//end Render
}//end VCExtendAddonBbpSearch


class VCExtendAddonBbpSearchForm extends VCExtendAddonWtr{

	public $base	= 'vc_wtr_bbp_search_form';
	public $fields	= array();

	//===FUNCTIONS
	public function __construct(){

		parent::__construct();

		// We safely integrate with VC with this hook
		add_action( 'init', array( &$this, 'integrateWithVC' ) );

		//Creating a shortcode addon
		add_shortcode( $this->base, array( &$this, 'render' ) );
	}//end __construct


	public function integrateWithVC(){
		// Map fields

		$this->fields = array(
			$this->getDefaultVCfield( 'el_class' ),
		);

		// animate attr
		$this->shtAnimateAttrGenerator( $this->fields, true );

		vc_map( array(
			'name'			=> __( 'Search form template', 'wtr_sht_framework' ),
			'description'	=> __( 'Display the search form template', 'wtr_sht_framework' ),
			'base'			=> $this->base,
			'class'			=> $this->base . '_div '. $this->wtrShtMainClass,
			'icon'			=> 'vc_wtr_bbp_icon',
			'controls'		=> 'full',
			'category'		=> $this->groupSht[ 'bbpress' ],
			'params'		=> $this->fields,
			)
		);
	}//end integrateWithVC


	public function render( $atts, $content = null ){
		$atts	= $this->prepareCorrectShortcode( $this->fields, $atts );
		extract( $atts );

		$class_html_attr	= 'wtrBbp-search-form ' . $el_class;

		$result	='<div' . $this->shtAnimateHTML( $class_html_attr, $atts ) . ' >[bbp-search-form]</div>';
		$result = do_shortcode( $result );

		return $result;
	}//end Render
}//end VCExtendAddonBbpSearchForm


class VCExtendAddonBbpSingleView extends VCExtendAddonWtr{

	public $base	= 'vc_wtr_bbp_single_view';
	public $fields	= array();

	//===FUNCTIONS
	public function __construct(){

		parent::__construct();

		// We safely integrate with VC with this hook
		add_action( 'init', array( &$this, 'integrateWithVC' ) );

		//Creating a shortcode addon
		add_shortcode( $this->base, array( &$this, 'render' ) );
	}//end __construct


	public function integrateWithVC(){
		// Map fields

		$this->fields = array(
			array(
				'param_name'	=> 'wtr_id',
				'heading'		=> __( 'Id', 'wtr_sht_framework' ),
				'description'	=> __( 'Display topics associated with a specific view. Current included "views" with
										bbPress are "popular" - popular AND "No Replies"- no-replies', 'wtr_sht_framework' ),
				'type'			=> 'textfield',
				'value'			=> __( '', 'wtr_sht_framework' ),
				'admin_label' 	=> true,
				'class'			=> $this->base . '_id_class',
			),

			$this->getDefaultVCfield( 'el_class' ),
		);

		// animate attr
		$this->shtAnimateAttrGenerator( $this->fields, true );

		vc_map( array(
			'name'			=> __( 'Single view', 'wtr_sht_framework' ),
			'description'	=> '',
			'base'			=> $this->base,
			'class'			=> $this->base . '_div '. $this->wtrShtMainClass,
			'icon'			=> 'vc_wtr_bbp_icon',
			'controls'		=> 'full',
			'category'		=> $this->groupSht[ 'bbpress' ],
			'params'		=> $this->fields,
			)
		);
	}//end integrateWithVC


	public function render( $atts, $content = null ){
		$atts	= $this->prepareCorrectShortcode( $this->fields, $atts );
		extract( $atts );

		$wtr_id = ' id="' . trim( $wtr_id ) . '"';
		$class_html_attr	= 'wtrBbp-single-view ' . $el_class;

		$result	='<div' . $this->shtAnimateHTML( $class_html_attr, $atts ) . ' >[bbp-single-view' . $wtr_id . ']</div>';
		$result = do_shortcode( $result );

		return $result;
	}//end Render
}//end VCExtendAddonBbpSingleView


class VCExtendAddonBbpSingleTag extends VCExtendAddonWtr{

	public $base	= 'vc_wtr_bbp_single_tag';
	public $fields	= array();

	//===FUNCTIONS
	public function __construct(){

		parent::__construct();

		// We safely integrate with VC with this hook
		add_action( 'init', array( &$this, 'integrateWithVC' ) );

		//Creating a shortcode addon
		add_shortcode( $this->base, array( &$this, 'render' ) );
	}//end __construct


	public function integrateWithVC(){
		// Map fields

		$this->fields = array(
			array(
				'param_name'	=> 'wtr_id',
				'heading'		=> __( 'Tag id', 'wtr_sht_framework' ),
				'description'	=> __( 'Display a list of all topics associated with a specific tag', 'wtr_sht_framework' ),
				'type'			=> 'textfield',
				'value'			=> __( '', 'wtr_sht_framework' ),
				'admin_label' 	=> true,
				'class'			=> $this->base . '_id_class',
			),

			$this->getDefaultVCfield( 'el_class' ),
		);

		// animate attr
		$this->shtAnimateAttrGenerator( $this->fields, true );

		vc_map( array(
			'name'			=> __( 'Single tag', 'wtr_sht_framework' ),
			'description'	=> '',
			'base'			=> $this->base,
			'class'			=> $this->base . '_div '. $this->wtrShtMainClass,
			'icon'			=> 'vc_wtr_bbp_icon',
			'controls'		=> 'full',
			'category'		=> $this->groupSht[ 'bbpress' ],
			'params'		=> $this->fields,
			)
		);
	}//end integrateWithVC


	public function render( $atts, $content = null ){
		$atts	= $this->prepareCorrectShortcode( $this->fields, $atts );
		extract( $atts );

		$wtr_id = ' id="' . trim( $wtr_id ) . '"';
		$class_html_attr	= 'wtrBbp-single-tag ' . $el_class;

		$result	='<div' . $this->shtAnimateHTML( $class_html_attr, $atts ) . ' >[bbp-single-tag' . $wtr_id . ']</div>';
		$result = do_shortcode( $result );

		return $result;
	}//end Render
}//end VCExtendAddonBbpSingleTag


class VCExtendAddonBbpTopicTags extends VCExtendAddonWtr{

	public $base	= 'vc_wtr_bbp_topic_tags';
	public $fields	= array();

	//===FUNCTIONS
	public function __construct(){

		parent::__construct();

		// We safely integrate with VC with this hook
		add_action( 'init', array( &$this, 'integrateWithVC' ) );

		//Creating a shortcode addon
		add_shortcode( $this->base, array( &$this, 'render' ) );
	}//end __construct


	public function integrateWithVC(){
		// Map fields

		$this->fields = array(
			$this->getDefaultVCfield( 'el_class' ),
		);

		// animate attr
		$this->shtAnimateAttrGenerator( $this->fields, true );

		vc_map( array(
			'name'			=> __( 'Topic tags', 'wtr_sht_framework' ),
			'description'	=> __( 'Display a tag cloud of all topic tags', 'wtr_sht_framework' ),
			'base'			=> $this->base,
			'class'			=> $this->base . '_div '. $this->wtrShtMainClass,
			'icon'			=> 'vc_wtr_bbp_icon',
			'controls'		=> 'full',
			'category'		=> $this->groupSht[ 'bbpress' ],
			'params'		=> $this->fields,
			)
		);
	}//end integrateWithVC


	public function render( $atts, $content = null ){
		$atts	= $this->prepareCorrectShortcode( $this->fields, $atts );
		extract( $atts );

		$class_html_attr	= 'wtrBbp-topic-tag ' . $el_class;

		$result = '<div id="wtrBbp-topic-tag">';
			$result	.='<div' . $this->shtAnimateHTML( $class_html_attr, $atts ) . ' >[bbp-topic-tags]</div>';
		$result .= '</div>';
		$result = do_shortcode( $result );

		return $result;
	}//end Render
}//end VCExtendAddonBbpTopicTags


class VCExtendAddonBbpSingleTopic extends VCExtendAddonWtr{

	public $base	= 'vc_wtr_bbp_single_topic';
	public $fields	= array();

	//===FUNCTIONS
	public function __construct(){

		parent::__construct();

		// We safely integrate with VC with this hook
		add_action( 'init', array( &$this, 'integrateWithVC' ) );

		//Creating a shortcode addon
		add_shortcode( $this->base, array( &$this, 'render' ) );
	}//end __construct


	public function integrateWithVC(){
		// Map fields

		$this->fields = array(
			array(
				'param_name'	=> 'wtr_id',
				'heading'		=> __( 'Topic id', 'wtr_sht_framework' ),
				'description'	=> '',
				'type'			=> 'textfield',
				'value'			=> __( '', 'wtr_sht_framework' ),
				'admin_label' 	=> true,
				'class'			=> $this->base . '_id_class',
			),

			$this->getDefaultVCfield( 'el_class' ),
		);

		// animate attr
		$this->shtAnimateAttrGenerator( $this->fields, true );

		vc_map( array(
			'name'			=> __( 'Single topic', 'wtr_sht_framework' ),
			'description'	=> '',
			'base'			=> $this->base,
			'class'			=> $this->base . '_div '. $this->wtrShtMainClass,
			'icon'			=> 'vc_wtr_bbp_icon',
			'controls'		=> 'full',
			'category'		=> $this->groupSht[ 'bbpress' ],
			'params'		=> $this->fields,
			)
		);
	}//end integrateWithVC


	public function render( $atts, $content = null ){
		$atts	= $this->prepareCorrectShortcode( $this->fields, $atts );
		extract( $atts );

		$class_html_attr	= 'wtrBbp-topic-form ' . $el_class;
		$wtr_id = ' id="' . trim( $wtr_id ) . '"';

		$result = '<div id="wtrBbp-topic-form">';
			$result	.='<div' . $this->shtAnimateHTML( $class_html_attr, $atts ) . ' >[bbp-single-topic' . $wtr_id . ']</div>';
		$result .= '</div>';

		$result = do_shortcode( $result );

		return $result;
	}//end Render
}//end VCExtendAddonBbpSingleTopic


class VCExtendAddonBbpSingleForum extends VCExtendAddonWtr{

	public $base	= 'vc_wtr_bbp_single_forum';
	public $fields	= array();

	//===FUNCTIONS
	public function __construct(){

		parent::__construct();

		// We safely integrate with VC with this hook
		add_action( 'init', array( &$this, 'integrateWithVC' ) );

		//Creating a shortcode addon
		add_shortcode( $this->base, array( &$this, 'render' ) );
	}//end __construct


	public function integrateWithVC(){
		// Map fields

		$this->fields = array(
			array(
				'param_name'	=> 'wtr_id',
				'heading'		=> __( 'Forum id', 'wtr_sht_framework' ),
				'description'	=> '',
				'type'			=> 'textfield',
				'value'			=> __( '', 'wtr_sht_framework' ),
				'admin_label' 	=> true,
				'class'			=> $this->base . '_id_class',
			),

			$this->getDefaultVCfield( 'el_class' ),
		);

		// animate attr
		$this->shtAnimateAttrGenerator( $this->fields, true );

		vc_map( array(
			'name'			=> __( 'Single forum', 'wtr_sht_framework' ),
			'description'	=> '',
			'base'			=> $this->base,
			'class'			=> $this->base . '_div '. $this->wtrShtMainClass,
			'icon'			=> 'vc_wtr_bbp_icon',
			'controls'		=> 'full',
			'category'		=> $this->groupSht[ 'bbpress' ],
			'params'		=> $this->fields,
			)
		);
	}//end integrateWithVC


	public function render( $atts, $content = null ){
		$atts	= $this->prepareCorrectShortcode( $this->fields, $atts );
		extract( $atts );

		$class_html_attr	= 'wtrBbp-single-forum ' . $el_class;
		$wtr_id = ' id="' . trim( $wtr_id ) . '"';

		$result = '<div id="wtrBbp-single-forum">';
			$result	.='<div' . $this->shtAnimateHTML( $class_html_attr, $atts ) . ' >[bbp-single-forum' . $wtr_id . ']</div>';
		$result .= '</div>';

		$result = do_shortcode( $result );

		return $result;
	}//end Render
}//end VCExtendAddonBbpSingleForum


class VCExtendAddonBbpForumForm extends VCExtendAddonWtr{

	public $base	= 'vc_wtr_bbp_forum_form';
	public $fields	= array();

	//===FUNCTIONS
	public function __construct(){

		parent::__construct();

		// We safely integrate with VC with this hook
		add_action( 'init', array( &$this, 'integrateWithVC' ) );

		//Creating a shortcode addon
		add_shortcode( $this->base, array( &$this, 'render' ) );
	}//end __construct


	public function integrateWithVC(){
		// Map fields

		$this->fields = array(
			$this->getDefaultVCfield( 'el_class' ),
		);

		// animate attr
		$this->shtAnimateAttrGenerator( $this->fields, true );

		vc_map( array(
			'name'			=> __( 'Forum form', 'wtr_sht_framework' ),
			'description'	=> '',
			'base'			=> $this->base,
			'class'			=> $this->base . '_div '. $this->wtrShtMainClass,
			'icon'			=> 'vc_wtr_bbp_icon',
			'controls'		=> 'full',
			'category'		=> $this->groupSht[ 'bbpress' ],
			'params'		=> $this->fields,
			)
		);
	}//end integrateWithVC


	public function render( $atts, $content = null ){
		$atts	= $this->prepareCorrectShortcode( $this->fields, $atts );
		extract( $atts );

		$class_html_attr	= 'wtrBbp-forum-forum ' . $el_class;

		$result = '<div id="bbpress-forums">';
			$result	.='<div' . $this->shtAnimateHTML( $class_html_attr, $atts ) . ' >[bbp-forum-form]</div>';
		$result .= '</div>';
		$result = do_shortcode( $result );

		return $result;
	}//end Render
}//end VCExtendAddonBbpForumForm



class VCExtendAddonBbpReplyForm extends VCExtendAddonWtr{

	public $base	= 'vc_wtr_bbp_reply_form';
	public $fields	= array();

	//===FUNCTIONS
	public function __construct(){

		parent::__construct();

		// We safely integrate with VC with this hook
		add_action( 'init', array( &$this, 'integrateWithVC' ) );

		//Creating a shortcode addon
		add_shortcode( $this->base, array( &$this, 'render' ) );
	}//end __construct


	public function integrateWithVC(){
		// Map fields

		$this->fields = array(
			$this->getDefaultVCfield( 'el_class' ),
		);

		// animate attr
		$this->shtAnimateAttrGenerator( $this->fields, true );

		vc_map( array(
			'name'			=> __( 'Reply form', 'wtr_sht_framework' ),
			'description'	=> '',
			'base'			=> $this->base,
			'class'			=> $this->base . '_div '. $this->wtrShtMainClass,
			'icon'			=> 'vc_wtr_bbp_icon',
			'controls'		=> 'full',
			'category'		=> $this->groupSht[ 'bbpress' ],
			'params'		=> $this->fields,
			)
		);
	}//end integrateWithVC


	public function render( $atts, $content = null ){
		$atts	= $this->prepareCorrectShortcode( $this->fields, $atts );
		extract( $atts );

		$class_html_attr	= 'wtrBbp-reply-form ' . $el_class;

		$result = '<div id="bbpress-forums">';
			$result	.='<div' . $this->shtAnimateHTML( $class_html_attr, $atts ) . ' >[bbp-reply-form]</div>';
		$result .= '</div>';
		$result = do_shortcode( $result );

		return $result;
	}//end Render
}//end VCExtendAddonBbpReplyForm


class VCExtendAddonBbpSingleReply extends VCExtendAddonWtr{

	public $base	= 'vc_wtr_bbp_single_reply';
	public $fields	= array();

	//===FUNCTIONS
	public function __construct(){

		parent::__construct();

		// We safely integrate with VC with this hook
		add_action( 'init', array( &$this, 'integrateWithVC' ) );

		//Creating a shortcode addon
		add_shortcode( $this->base, array( &$this, 'render' ) );
	}//end __construct


	public function integrateWithVC(){
		// Map fields

		$this->fields = array(
			array(
				'param_name'	=> 'wtr_id',
				'heading'		=> __( 'Reply id', 'wtr_sht_framework' ),
				'description'	=> '',
				'type'			=> 'textfield',
				'value'			=> __( '', 'wtr_sht_framework' ),
				'admin_label' 	=> true,
				'class'			=> $this->base . '_id_class',
			),

			$this->getDefaultVCfield( 'el_class' ),
		);

		// animate attr
		$this->shtAnimateAttrGenerator( $this->fields, true );

		vc_map( array(
			'name'			=> __( 'Single reply', 'wtr_sht_framework' ),
			'description'	=> '',
			'base'			=> $this->base,
			'class'			=> $this->base . '_div '. $this->wtrShtMainClass,
			'icon'			=> 'vc_wtr_bbp_icon',
			'controls'		=> 'full',
			'category'		=> $this->groupSht[ 'bbpress' ],
			'params'		=> $this->fields,
			)
		);
	}//end integrateWithVC


	public function render( $atts, $content = null ){
		$atts	= $this->prepareCorrectShortcode( $this->fields, $atts );
		extract( $atts );

		$class_html_attr	= 'wtrBbp-single-reply ' . $el_class;
		$wtr_id = ' id="' . trim( $wtr_id ) . '"';

		$result	='<div' . $this->shtAnimateHTML( $class_html_attr, $atts ) . ' >[bbp-single-reply' . $wtr_id . ']</div>';
		$result = do_shortcode( $result );

		return $result;
	}//end Render
}//end VCExtendAddonBbpSingleReply



class VCExtendAddonBbpTopicForum extends VCExtendAddonWtr{

	public $base	= 'vc_wtr_bbp_topic_forum';
	public $fields	= array();

	//===FUNCTIONS
	public function __construct(){

		parent::__construct();

		// We safely integrate with VC with this hook
		add_action( 'init', array( &$this, 'integrateWithVC' ) );

		//Creating a shortcode addon
		add_shortcode( $this->base, array( &$this, 'render' ) );
	}//end __construct


	public function integrateWithVC(){
		// Map fields

		$this->fields = array(
			array(
				'param_name'	=> 'wtr_id',
				'heading'		=> __( 'Topic forum id', 'wtr_sht_framework' ),
				'description'	=> __( 'If there is no forum ID display ‘New Topic’ form where you can choose from a drop
										down menu the forum that this topic is to be associated with.', 'wtr_sht_framework' ),
				'type'			=> 'textfield',
				'value'			=> __( '', 'wtr_sht_framework' ),
				'admin_label' 	=> true,
				'class'			=> $this->base . '_id_class',
			),

			$this->getDefaultVCfield( 'el_class' ),
		);

		// animate attr
		$this->shtAnimateAttrGenerator( $this->fields, true );

		vc_map( array(
			'name'			=> __( 'Topic forum', 'wtr_sht_framework' ),
			'description'	=> '',
			'base'			=> $this->base,
			'class'			=> $this->base . '_div '. $this->wtrShtMainClass,
			'icon'			=> 'vc_wtr_bbp_icon',
			'controls'		=> 'full',
			'category'		=> $this->groupSht[ 'bbpress' ],
			'params'		=> $this->fields,
			)
		);
	}//end integrateWithVC


	public function render( $atts, $content = null ){
		$atts	= $this->prepareCorrectShortcode( $this->fields, $atts );
		extract( $atts );

		$class_html_attr	= 'wtrBbp-topic-form ' . $el_class;
		$wtr_id = trim( $wtr_id );

		if( strlen( $wtr_id ) ){
			$flag = true;
			$wtr_id = ' forum_id="' . trim( $wtr_id ) . '"';
		}else{
			$flag = false;
		}

		$result = '';
		if( $flag ){ $result .= '<div id="bbpress-forums">'; }
			$result	.='<div' . $this->shtAnimateHTML( $class_html_attr, $atts ) . ' >[bbp-topic-form' . $wtr_id . ']</div>';
		if( $flag ){ $result .= '</div>'; }
		$result = do_shortcode( $result );

		return $result;
	}//end Render
}//end VCExtendAddonBbpTopicForum



class VCExtendAddonBbpForums extends VCExtendAddonWtr{

	public $base	= 'vc_wtr_bbp_forums';
	public $fields	= array();

	//===FUNCTIONS
	public function __construct(){

		parent::__construct();

		// We safely integrate with VC with this hook
		add_action( 'init', array( &$this, 'integrateWithVC' ) );

		//Creating a shortcode addon
		add_shortcode( $this->base, array( &$this, 'render' ) );
	}//end __construct


	public function integrateWithVC(){
		// Map fields

		$this->fields = array(
			$this->getDefaultVCfield( 'el_class' ),
		);

		// animate attr
		$this->shtAnimateAttrGenerator( $this->fields, true );

		vc_map( array(
			'name'			=> __( 'Topic index', 'wtr_sht_framework' ),
			'description'	=> __( 'Display the most recent 15 topics across all your forums', 'wtr_sht_framework' ),
			'base'			=> $this->base,
			'class'			=> $this->base . '_div '. $this->wtrShtMainClass,
			'icon'			=> 'vc_wtr_bbp_icon',
			'controls'		=> 'full',
			'category'		=> $this->groupSht[ 'bbpress' ],
			'params'		=> $this->fields,
			)
		);
	}//end integrateWithVC


	public function render( $atts, $content = null ){
		$atts	= $this->prepareCorrectShortcode( $this->fields, $atts );
		extract( $atts );

		$class_html_attr	= 'wtrBbp-topic-index ' . $el_class;

		$result = '<div id="bbpress-forums">';
			$result	.='<div' . $this->shtAnimateHTML( $class_html_attr, $atts ) . ' >[bbp-topic-index]</div>';
		$result .= '</div>';
		$result = do_shortcode( $result );

		return $result;
	}//end Render
}//end VCExtendAddonBbpForums


class VCExtendAddonBbpStats extends VCExtendAddonWtr{

	public $base	= 'vc_wtr_bbp_stats';
	public $fields	= array();

	//===FUNCTIONS
	public function __construct(){

		parent::__construct();

		// We safely integrate with VC with this hook
		add_action( 'init', array( &$this, 'integrateWithVC' ) );

		//Creating a shortcode addon
		add_shortcode( $this->base, array( &$this, 'render' ) );
	}//end __construct


	public function integrateWithVC(){
		// Map fields

		$this->fields = array(
			$this->getDefaultVCfield( 'el_class' ),
		);

		// animate attr
		$this->shtAnimateAttrGenerator( $this->fields, true );

		vc_map( array(
			'name'			=> __( 'Stats', 'wtr_sht_framework' ),
			'description'	=> __( 'Display the forum statistics', 'wtr_sht_framework' ),
			'base'			=> $this->base,
			'class'			=> $this->base . '_div '. $this->wtrShtMainClass,
			'icon'			=> 'vc_wtr_bbp_icon',
			'controls'		=> 'full',
			'category'		=> $this->groupSht[ 'bbpress' ],
			'params'		=> $this->fields,
			)
		);
	}//end integrateWithVC


	public function render( $atts, $content = null ){
		$atts	= $this->prepareCorrectShortcode( $this->fields, $atts );
		extract( $atts );

		$class_html_attr	= 'wtrBbp-stats ' . $el_class;

		$result	='<div' . $this->shtAnimateHTML( $class_html_attr, $atts ) . ' >[bbp-stats]</div>';
		$result = do_shortcode( $result );

		return $result;
	}//end Render
}//end VCExtendAddonBbpStats


//== Create bbPress Sht Object
new VCExtendAddonBbpForumIndex();
new VCExtendAddonBbpLogin();
new VCExtendAddonBbpRegister();
new VCExtendAddonBbpLostPass();
new VCExtendAddonBbpSearch();
new VCExtendAddonBbpSearchForm();
new VCExtendAddonBbpSingleView();
new VCExtendAddonBbpSingleTag();
new VCExtendAddonBbpTopicTags();
new VCExtendAddonBbpSingleTopic();
new VCExtendAddonBbpSingleForum();
new VCExtendAddonBbpForumForm();
new VCExtendAddonBbpReplyForm();
new VCExtendAddonBbpSingleReply();
new VCExtendAddonBbpTopicForum();
new VCExtendAddonBbpForums();
new VCExtendAddonBbpStats();